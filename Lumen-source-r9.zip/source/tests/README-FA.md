# آزمون‌های سورس R9

## آزمون‌های Revision 9

- `test-sidecar-matcher.js`: هشت آزمون Node بدون dependency برای نام دقیق، تبدیل SRT به WebVTT، شماره‌ی اپیزود، فارسی/Unicode و ارقام فارسی، پوشه‌ی شلوغ، زیرپوشه‌ی `Subs`، رد موارد مبهم و رد فایل متنی غیرزیرنویس؛ **۸/۸ PASS**.
- `test-source-ui.js`: هفت بررسی ساختاری برای حذف Preview، حفظ Reset/style، ادغام sidecar، NSIS و fallback دانلود BAT؛ **۷/۷ PASS**.
- `results-r9-source.json`: نتایج و محدودیت‌های محیط R9.

## سوابق Revision 8 و R7

- `results-r8-source.json`: تست‌های سورس R8 (قبل از اصلاح خطای TLS در BAT).
- `harness-round7.js`: آزمون Electron/UI تاریخی برای clipboard، About، پوستر، حذف Screenshot و منوی راست‌کلیک در desktop/touch. شناسه‌ی About آن برای سورس R9 به‌روزرسانی شده است. برای اجرای harness باید به انتهای یک کپی موقت از `main.js` افزوده شود؛ جزو build محصول نیست.
- `make-r7-fixtures.sh`: ساخت فایل‌های کوچک HEVC و subtitle با FFmpeg محیط آزمون.
- `test-r7-codecs.js` و فایل‌های `results-r7-*`: آزمون‌های تاریخی کدک و UI.

تست‌های R9 روی Linux x64 اجرا شدند. BAT و نصاب Windows روی Windows واقعی در این محیط اجرا نشده‌اند. مسیر fallback برای خطای Schannel از نظر ساختاری آزمون شد؛ اجرای خود `curl.exe --ssl-no-revoke` در ویندوز کاربر باید تأیید نهایی شود. SHA-256 pinned پس از دانلود همچنان در BAT بررسی می‌شود.
