'use strict';
/* Static checks for the requested subtitle-settings change and async sidecar merge. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = function (p) { return fs.readFileSync(path.join(root, p), 'utf8'); };
const html = read('web/index.html');
const css = read('web/app.css');
const shell = read('web/shell.js');
const ui = read('web/ui.js');
const app = read('web/app.js');
const installer = read('tools/build-installer.js');
const bat = read('build-windows-r9.bat');
const results = [];
function check(name, fn) {
  fn();
  results.push(name);
  console.log('PASS ' + name);
}

check('Settings contains no subtitle sample preview element or row', function () {
  assert.doesNotMatch(html, /id=["']subPreview["']/i);
  assert.doesNotMatch(html, /<span[^>]*>\s*Preview\s*</i);
  assert.doesNotMatch(css, /sub-preview/i);
  assert.doesNotMatch(shell, /subPreview|sub-preview/i);
});
check('Reset look remains bound to the style reset handler', function () {
  assert.match(html, /id=["']subResetBtn["']/);
  assert.match(ui, /subResetBtn[\s\S]{0,180}subStyleReset/);
  assert.match(shell, /L\.subStyleReset\s*=\s*function/);
});
check('real subtitle styling still renders on player cues', function () {
  assert.match(shell, /L\.subStyleApply\s*=\s*function\s*\(\)\s*\{\s*P\.renderSubs/);
  assert.match(app, /function subInlineStyle\(\)/);
  assert.match(app, /inline:\s*subInlineStyle/);
  assert.match(css, /\.sub-line/);
});
check('sidecar tracks survive a slower embedded-track probe', function () {
  assert.match(app, /var foundSidecars\s*=\s*self\.subTracks\.filter/);
  assert.match(app, /foundSidecars\.forEach/);
  assert.match(app, /self\.subTracks\s*=\s*\(info\.subs\s*\|\|\s*\[\]\)\.slice\(0\)/);
});
check('renderer sidecar merge is case-insensitive and idempotent', function () {
  assert.match(app, /function sidecarPathKey\(p\)/);
  assert.match(app, /var known = new Set\(self\.subTracks/);
  assert.match(app, /if \(!add\.length\) return/);
});
check('installer discovery checks where.exe/PATH and Program Files on Windows', function () {
  assert.match(installer, /process\.platform === 'win32'/);
  assert.match(installer, /where\.exe/);
  assert.match(installer, /ProgramFiles\(x86\)/);
  assert.doesNotMatch(installer, /spawnSync\('which'/);
});
check('R9 BAT build ID/output, Node/NSIS prerequisites, and revocation fallback are aligned', function () {
  assert.ok(bat.includes('build\\r9'));
  assert.ok(bat.includes('--build-id r9-2026-10-04'));
  assert.ok(bat.includes('--revision r9'));
  assert.ok(bat.includes('Node.js 22.12 or newer'));
  assert.ok(bat.includes('where.exe makensis.exe'));
  assert.equal((bat.match(/curl\.exe --ssl-no-revoke/g) || []).length, 2);
  assert.match(bat, /FFMPEG_SHA/);
  assert.match(bat, /ELECTRON_SHA/);
});

console.log('\n' + results.length + '/7 UI/source/BAT static checks passed.');
